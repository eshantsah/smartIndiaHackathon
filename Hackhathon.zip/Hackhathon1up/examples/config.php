<?php

// To send request to firebase endpoint

// define Firebase SERVER API Key
define('FIREBASE_API_KEY','AAAA6z5YQ9s:APA91bGD54jsuDbY0P2XihFutDJGFh3DB6lqOYmhgrnpib2mHEd2XCRT095vDO2NkpEiBftK6zF_HY0dgxqd6Um_Y5Q-4YNQjNmnr-pnmK3P81GAzwN4Vj6LiF5PkLEdeMV_6nzhhilM');

?>