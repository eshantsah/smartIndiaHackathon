<!DOCTYPE html>
<html>
<body>

<?php

echo(rand(1,3));
?>

</body>
</html>