
	


<?php
<script type="text/javascript">
alert("review your answer");
window.location.href = "dashboard.php";
</script>
?>