<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png" />
	<link rel="icon" type="image/png" href="../assets/img/favicon.png" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>DAE Crisis Management :: Crisis Cross</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />

    <!--  Material Dashboard CSS    -->
    <link href="../assets/css/material-dashboard.css" rel="stylesheet"/>

    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="../assets/css/demo.css" rel="stylesheet" />

    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300|Material+Icons' rel='stylesheet' type='text/css'>

</head>

<body>

<div class = "container">
	<div class="wrapper">
		<div class = "logo">
			<img class="center-block" src="../assets/img/dae_logo.png">
				<form action="" method="post" name="Login_Form" class="form-signin">       
				    <h3 class="form-signin-heading">Welcome to the Department of Atomic Energy. <br /> Please Sign In.</h3>
					  <hr class="colorgraph"><br>
					  
					  <input type="text" class="form-control" name="email" placeholder="Username" required="" autofocus="" />
					  <input type="password" class="form-control" name="Password" placeholder="Password" required=""/>     		  
					 
					  <button class="btn btn-lg btn-primary btn-block"  name="submit" value="Login" type="Submit">Login</button>  			
				</form>	
			</div>	
	</div>
</div>
	
</body>

	<!--   Core JS Files   -->
	<script src="../assets/js/jquery-3.1.0.min.js" type="text/javascript"></script>
	<script src="../assets/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="../assets/js/material.min.js" type="text/javascript"></script>

	<!--  Charts Plugin -->
	<script src="../assets/js/chartist.min.js"></script>

	<!--  Notifications Plugin    -->
	<script src="../assets/js/bootstrap-notify.js"></script>

	<!--  Google Maps Plugin    -->
	<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

	<!-- Material Dashboard javascript methods -->
	<script src="../assets/js/material-dashboard.js"></script>

	<!-- Material Dashboard DEMO methods, don't include it in your project! -->
	<script src="../assets/js/demo.js"></script>

</html>




<?php
if(isset($_POST['submit'])){

include('dbcon.php');

$email=$_POST['email'];
$password=$_POST['Password'];
$query="SELECT * FROM admin WHERE email='$email' AND password='$password'";
$result=mysqli_query($con,$query);
$row=mysqli_num_rows($result);
if($row>0)
{
$data=mysqli_fetch_assoc($result);

header('location:dashboard.php');

$id=$data['id'];
$name=$data['Name'];

$adharno=$data['adharno'];
session_start();
$_SESSION['uid']=$id;
$_SESSION['uname']=$name;
$_SESSION['uadharno']=$adharno;

}

else
{
echo"wrong id or passowrd";
}

}






?>
