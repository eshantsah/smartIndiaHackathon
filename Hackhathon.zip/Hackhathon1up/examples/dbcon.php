<?php

 
//$con = mysqli_connect('mysql.hostinger.in','u283293192_cms','123456789','u283293192_cms');//



$con = mysqli_connect('localhost','root','123456789','cms');

?>

